﻿param([string]$TargetDir)
$ErrorActionPreference = 'Stop'

$expectedExeSha256 = '2F489A49EA457FB8D754F2550F24B24346EB2F5DB7E358BC659116E4BAFCA2BE'
$exeName = ([string][char]0x661F) + ([string][char]0x77B3) + '.exe'
$payload = Join-Path $PSScriptRoot 'payload'

function Select-InstallFolder([string]$InitialPath) {
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = 'Select the XingTong 1.9.0.2 folder that contains the application EXE.'
    if ($InitialPath -and (Test-Path -LiteralPath $InitialPath)) { $dialog.SelectedPath = $InitialPath }
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { throw 'Installation cancelled.' }
    return $dialog.SelectedPath
}

function Test-LocalPort([string]$Address, [int]$Port) {
    $client = [System.Net.Sockets.TcpClient]::new()
    try {
        $async = $client.BeginConnect($Address, $Port, $null, $null)
        if (-not $async.AsyncWaitHandle.WaitOne(400)) { return $false }
        $client.EndConnect($async)
        return $true
    } catch { return $false } finally { $client.Dispose() }
}

if (-not $TargetDir) { $TargetDir = Select-InstallFolder '' }
$TargetDir = [IO.Path]::GetFullPath($TargetDir)
$targetExe = Join-Path $TargetDir $exeName
$serviceDir = Join-Path $TargetDir '_offline'
$serviceExe = Join-Path $payload '_offline\MStarBotOfflineAuth.exe'

if (-not (Test-Path -LiteralPath $targetExe -PathType Leaf)) { throw "Target EXE not found: $targetExe" }
if (-not (Test-Path -LiteralPath $serviceExe -PathType Leaf)) { throw 'Package is incomplete: MStarBotOfflineAuth.exe is missing.' }

$currentHash = (Get-FileHash -LiteralPath $targetExe -Algorithm SHA256).Hash
if ($currentHash -ne $expectedExeSha256) {
    throw "Unsupported application build. Expected XingTong 1.9.0.2 SHA-256 $expectedExeSha256, found $currentHash"
}

$runningApp = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
    $_.ExecutablePath -and [IO.Path]::GetFullPath([string]$_.ExecutablePath) -eq $targetExe
}
if ($runningApp) { throw 'Please close XingTong before installation.' }

$servicePrefix = [IO.Path]::GetFullPath($serviceDir) + [IO.Path]::DirectorySeparatorChar
$runningService = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
    $_.ExecutablePath -and [IO.Path]::GetFullPath([string]$_.ExecutablePath).StartsWith($servicePrefix, [StringComparison]::OrdinalIgnoreCase)
}
if ($runningService) {
    throw 'Offline service is still running. Run the stop-service BAT first, then install again.'
}
if (Test-LocalPort '127.0.0.1' 8765) {
    Write-Warning 'Port 8765 is currently occupied by a service outside the selected test folder. Installation will continue, but stop that service before launching this installation.'
}

$managedFiles = @(
    'auth_api_config.json',
    'offline-launch.ps1',
    'offline-stop.ps1',
    'offline-diagnose.ps1',
    ([string][char]0x661F + [string][char]0x77B3 + '-離線模式.bat'),
    '停止星瞳離線服務.bat',
    '離線診斷.bat',
    '_offline\MStarBotOfflineAuth.exe',
    '_offline\MStarBotOfflineAuth.ompayload',
    '_offline\mock_commerce_state.json'
)

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backupDir = Join-Path $TargetDir "backup\offline-service-1.9.0.2-$stamp"
$backupFiles = Join-Path $backupDir 'files'
New-Item -ItemType Directory -Path $backupFiles -Force | Out-Null
$backupItems = @()
foreach ($relative in $managedFiles) {
    $source = Join-Path $TargetDir $relative
    $existed = Test-Path -LiteralPath $source -PathType Leaf
    if ($existed) {
        $destination = Join-Path $backupFiles $relative
        New-Item -ItemType Directory -Path (Split-Path $destination -Parent) -Force | Out-Null
        Copy-Item -LiteralPath $source -Destination $destination -Force
    }
    $backupItems += [ordered]@{ relative_path = $relative; existed = [bool]$existed }
}
$backupManifest = [ordered]@{ schema_version = 1; items = $backupItems }
$backupManifest | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $backupDir 'backup-manifest.json') -Encoding UTF8

New-Item -ItemType Directory -Path $serviceDir -Force | Out-Null
Copy-Item -LiteralPath $serviceExe -Destination (Join-Path $serviceDir 'MStarBotOfflineAuth.exe') -Force
$staleProtectedPayload = Join-Path $serviceDir 'MStarBotOfflineAuth.ompayload'
if (Test-Path -LiteralPath $staleProtectedPayload -PathType Leaf) {
    Remove-Item -LiteralPath $staleProtectedPayload -Force
}
$stateSource = Join-Path $payload '_offline\mock_commerce_state.json'
if (Test-Path -LiteralPath $stateSource) { Copy-Item -LiteralPath $stateSource -Destination (Join-Path $serviceDir 'mock_commerce_state.json') -Force }

$installedKey = Join-Path $serviceDir 'MStarBotOfflineAuth.key'
if (-not (Test-Path -LiteralPath $installedKey)) {
    $keyCandidates = @(
        (Join-Path $PSScriptRoot 'MStarBotOfflineAuth.key'),
        (Join-Path $payload '_offline\MStarBotOfflineAuth.key'),
        (Join-Path $TargetDir 'MStarBotOfflineAuth.key')
    )
    $keySource = $keyCandidates | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
    if ($keySource) { Copy-Item -LiteralPath $keySource -Destination $installedKey -Force }
}

foreach ($name in @('offline-launch.ps1','offline-stop.ps1','offline-diagnose.ps1')) {
    Copy-Item -LiteralPath (Join-Path $payload $name) -Destination (Join-Path $TargetDir $name) -Force
}
Get-ChildItem -LiteralPath $payload -File -Filter '*.bat' | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $TargetDir $_.Name) -Force
}

$authJson = @{ auth_api_url = 'http://127.0.0.1:8765'; script_license_api_url = 'http://127.0.0.1:8765' } | ConvertTo-Json
[IO.File]::WriteAllText((Join-Path $TargetDir 'auth_api_config.json'), $authJson, [Text.UTF8Encoding]::new($false))

$finalHash = (Get-FileHash -LiteralPath $targetExe -Algorithm SHA256).Hash
if ($finalHash -ne $currentHash) { throw 'Safety check failed: 星瞳.exe changed during service-only installation.' }

$record = [ordered]@{
    schema_version = 1
    package_version = '1.9.0.2-unprotected-1'
    app_version = '1.9.0.2'
    installed_at = (Get-Date).ToString('o')
    target_dir = $TargetDir
    backup_dir = $backupDir
    app_exe_sha256 = $finalHash
    preserved_app_exe = $true
    key_preserved_or_imported = (Test-Path -LiteralPath $installedKey)
}
$record | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $TargetDir 'offline-service-install.json') -Encoding UTF8

Write-Host 'XingTong 1.9.0.2 offline service installed. Application EXE was preserved.' -ForegroundColor Green
Write-Host "Backup: $backupDir"
Write-Host 'Launch with 星瞳-離線模式.bat in the application folder.'

