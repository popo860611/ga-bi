# 星瞳 V1.9.0.7 離線版安裝包（未加殼）

此包只重新部署 `_offline` 授權服務與離線啟動／停止腳本，**不包含、不修改、不覆蓋 `星瞳.exe`**。本版的 `MStarBotOfflineAuth.exe` 未加殼，不需要 `.ompayload`；日後若要保護服務，請另外使用加殼工具產生受保護版本。

支援的原始新版 EXE SHA-256：

```text
EAEA12EB0AA60E748018DC5F72D42B317278D21742FB78E6D05A5C4169C2C104
```

## 安裝前

1. 點擊舊的 `停止星瞳離線服務.bat`。
2. 完全關閉星瞳。
3. 確認沒有其他程式使用 `127.0.0.1:8765`。
4. 保留新版原始 `星瞳.exe`，不要使用任何 1.8.9.6 補丁覆蓋。

## 安裝

1. 雙擊 `安裝離線版.bat`。
2. 選擇包含新版 `星瞳.exe` 的資料夾。
3. 安裝器會驗證 SHA-256，只複製服務與腳本。
4. 未加殼版服務不需要 `MStarBotOfflineAuth.key`；若目標原本已有 KEY，安裝器仍會原樣保留，方便日後切換回加殼版。

離線啟動腳本會在不覆蓋其他設定的情況下，把 `LOCAL-LAB-001` 寫入 `config.json` 與 `ui_state.json` 的記住金鑰欄位；新電腦不需要第一次手動輸入。

若加殼包曾經只把 EXE 安裝到 `_offline`，離線啟動腳本會在啟動服務前，自動從同目錄的 `payload\_offline` 同步缺少或不同版本的 EXE／`.ompayload`，並在目標沒有 KEY 時同步 `.key`。因此只需執行 `星瞳-離線模式.bat`，不需先手動開啟服務。

安裝完成後應為：

```text
<星瞳資料夾>\
├─ 星瞳.exe                         # 原始 V1.9.0.7，不變
├─ 星瞳-離線模式.bat
├─ 停止星瞳離線服務.bat
├─ offline-launch.ps1
├─ offline-stop.ps1
└─ _offline\
   └─ MStarBotOfflineAuth.exe       # 未加殼單檔服務，不需要 KEY
```

## 測試方式

安裝後只點 `星瞳-離線模式.bat`，不要先手動點 `_offline\MStarBotOfflineAuth.exe`。

依序確認：

1. 星瞳可啟動並完成離線授權登入。
2. MASTER／AI 測謊額度等授權欄位正常。
3. 點停止 BAT 後服務停止。
4. 再次點離線模式 BAT 可重新開啟。
5. 重開機後只點離線模式 BAT 仍能自動啟動服務。

## 移除

先停止服務及關閉星瞳，再雙擊 `移除離線版.bat`。移除程序會還原安裝前的腳本與設定，保留機器 KEY 及備份資料夾，仍不修改 `星瞳.exe`。

## 驗證範圍

- 套件回歸：V1.9.0.7 雜湊檢查、EXE 不變、未加殼服務安裝、無 KEY 啟動、既有 KEY 保留、舊 `.ompayload` 備份與移除、隔離連接埠啟動／停止、PowerShell 5.1 與移除還原。
- 靜態比對：V1.9.0.7 與 V1.9.0.4 的 auth_manager、production_license_transport、device_identity 模組雜湊完全相同；授權服務協定可沿用，真實 UI 功能仍需人工驗證。
- 尚未完成：真實 V1.9.0.7 UI 登入、MASTER／AI 測謊、第二台電腦及重開機後人工操作驗證。

