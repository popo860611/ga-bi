﻿param([string]$TargetDir)
$ErrorActionPreference = 'Stop'

$expectedOriginal = 'CA84363CB4BBE712EB41BA0B2B4AFE76CFF22B488D970BB2414CE5569C4CB2F9'
$expectedPatched  = 'EFE1F3B71C69D02DD3938F1CA93993E5B04FD27D21560218FA44457BBC1A57F0'
$exeName = ([string][char]0x661F) + ([string][char]0x77B3) + '.exe'
$payload = Join-Path $PSScriptRoot 'payload'

function Select-InstallFolder([string]$InitialPath) {
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = 'Select the folder that contains the application EXE.'
    if ($InitialPath -and (Test-Path -LiteralPath $InitialPath)) { $dialog.SelectedPath = $InitialPath }
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { throw 'Installation cancelled.' }
    return $dialog.SelectedPath
}

if (-not $TargetDir) { $TargetDir = Select-InstallFolder '' }
$TargetDir = [IO.Path]::GetFullPath($TargetDir)
$targetExe = Join-Path $TargetDir $exeName
$payloadExe = Join-Path $payload $exeName
$serviceExe = Join-Path $payload '_offline\MStarBotOfflineAuth.exe'

if (-not (Test-Path -LiteralPath $targetExe)) { throw "Target EXE not found: $targetExe" }
if (-not (Test-Path -LiteralPath $payloadExe)) { throw 'Package payload is incomplete (application EXE missing).' }
if (-not (Test-Path -LiteralPath $serviceExe)) { throw 'Package payload is incomplete (offline service missing).' }

# A previous portable install can leave the localhost helper running even if
# its PID file was lost. Stop only the uniquely named offline helper before
# replacing it, then wait for Windows to release the executable image.
$oldHelpers = Get-Process -Name 'MStarBotOfflineAuth' -ErrorAction SilentlyContinue
if ($oldHelpers) {
    $oldHelpers | Stop-Process -Force -ErrorAction Stop
    $oldHelpers | Wait-Process -Timeout 10 -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 500
}

try {
    $lockProbe = [IO.File]::Open($targetExe, [IO.FileMode]::Open, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
    $lockProbe.Dispose()
} catch {
    throw 'The target EXE is in use. Please close the application before installation.'
}

$currentHash = (Get-FileHash -LiteralPath $targetExe -Algorithm SHA256).Hash
if ($currentHash -notin @($expectedOriginal,$expectedPatched)) {
    throw "Unsupported EXE build. Expected version 1.8.9.6 hash, found: $currentHash"
}
$payloadHash = (Get-FileHash -LiteralPath $payloadExe -Algorithm SHA256).Hash
if ($payloadHash -ne $expectedPatched) { throw "Payload hash mismatch: $payloadHash" }

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backupDir = Join-Path $TargetDir "backup\offline-1.8.9.6-$stamp"
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
Copy-Item -LiteralPath $targetExe -Destination (Join-Path $backupDir $exeName) -Force

$authConfig = Join-Path $TargetDir 'auth_api_config.json'
$authConfigExisted = Test-Path -LiteralPath $authConfig
if ($authConfigExisted) { Copy-Item -LiteralPath $authConfig -Destination (Join-Path $backupDir 'auth_api_config.json') -Force }

Copy-Item -LiteralPath $payloadExe -Destination $targetExe -Force
New-Item -ItemType Directory -Path (Join-Path $TargetDir '_offline') -Force | Out-Null
$installedService = Join-Path $TargetDir '_offline\MStarBotOfflineAuth.exe'
$copied = $false
for ($attempt = 1; $attempt -le 10; $attempt++) {
    try {
        Copy-Item -LiteralPath $serviceExe -Destination $installedService -Force
        $copied = $true
        break
    } catch [System.IO.IOException] {
        if ($attempt -eq 10) { throw }
        Start-Sleep -Milliseconds 500
    }
}
if (-not $copied) { throw 'Unable to replace the offline service.' }
if (Test-Path -LiteralPath (Join-Path $payload '_offline\mock_commerce_state.json')) {
    Copy-Item -LiteralPath (Join-Path $payload '_offline\mock_commerce_state.json') -Destination (Join-Path $TargetDir '_offline\mock_commerce_state.json') -Force
}

foreach ($name in @('offline-launch.ps1','offline-stop.ps1','offline-diagnose.ps1')) {
    Copy-Item -LiteralPath (Join-Path $payload $name) -Destination (Join-Path $TargetDir $name) -Force
}
Get-ChildItem -LiteralPath $payload -File -Filter '*.bat' | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $TargetDir $_.Name) -Force
}

$authJson = @{
    auth_api_url = 'http://127.0.0.1:8765'
    script_license_api_url = 'http://127.0.0.1:8765'
} | ConvertTo-Json
[IO.File]::WriteAllText($authConfig, $authJson, [Text.UTF8Encoding]::new($false))

$installRecord = [ordered]@{
    schema_version = 1
    package_version = '1.8.9.6-portable-1'
    installed_at = (Get-Date).ToString('o')
    target_dir = $TargetDir
    backup_dir = $backupDir
    original_exe_sha256 = $currentHash
    installed_exe_sha256 = $expectedPatched
    auth_config_existed = $authConfigExisted
}
$installRecord | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $TargetDir 'offline-patch-install.json') -Encoding UTF8

$installedHash = (Get-FileHash -LiteralPath $targetExe -Algorithm SHA256).Hash
if ($installedHash -ne $expectedPatched) { throw 'Post-install EXE verification failed.' }

Write-Host "Installed successfully: $TargetDir" -ForegroundColor Green
Write-Host "Backup: $backupDir"
Write-Host 'Launch with the offline-mode BAT file in the application folder.'

