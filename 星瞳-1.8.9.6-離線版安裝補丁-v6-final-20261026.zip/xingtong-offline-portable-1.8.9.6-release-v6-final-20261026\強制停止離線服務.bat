@echo off
setlocal
fltmc >nul 2>&1
if not "%errorlevel%"=="0" (
  powershell.exe -NoLogo -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
taskkill /F /T /IM MStarBotOfflineAuth.exe >nul 2>&1
timeout /t 2 /nobreak >nul
echo Offline authorization service stop requested.
pause

