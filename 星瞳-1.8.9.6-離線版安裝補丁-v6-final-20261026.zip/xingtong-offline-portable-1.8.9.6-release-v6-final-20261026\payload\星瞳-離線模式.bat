@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0offline-launch.ps1"
if errorlevel 1 pause

