﻿param([string]$TargetDir)
$ErrorActionPreference = 'Stop'
$exeName = ([string][char]0x661F) + ([string][char]0x77B3) + '.exe'

function Select-InstallFolder([string]$InitialPath) {
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = 'Select the application folder that contains offline-patch-install.json.'
    if ($InitialPath -and (Test-Path -LiteralPath $InitialPath)) { $dialog.SelectedPath = $InitialPath }
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { throw 'Restore cancelled.' }
    return $dialog.SelectedPath
}

if (-not $TargetDir) { $TargetDir = Select-InstallFolder '' }
$TargetDir = [IO.Path]::GetFullPath($TargetDir)
$recordPath = Join-Path $TargetDir 'offline-patch-install.json'
if (-not (Test-Path -LiteralPath $recordPath)) { throw "Install record not found: $recordPath" }
$record = Get-Content -LiteralPath $recordPath -Raw -Encoding UTF8 | ConvertFrom-Json
$backupDir = [string]$record.backup_dir
$backupExe = Join-Path $backupDir $exeName
if (-not (Test-Path -LiteralPath $backupExe)) { throw "Backup EXE not found: $backupExe" }

$targetExe = Join-Path $TargetDir $exeName
if (Test-Path -LiteralPath $targetExe) {
    try {
        $lockProbe = [IO.File]::Open($targetExe, [IO.FileMode]::Open, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
        $lockProbe.Dispose()
    } catch {
        throw 'The target EXE is in use. Please close the application before restore.'
    }
}

$stopScript = Join-Path $TargetDir 'offline-stop.ps1'
if (Test-Path -LiteralPath $stopScript) { & powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $stopScript | Out-Host }

Copy-Item -LiteralPath $backupExe -Destination (Join-Path $TargetDir $exeName) -Force
$authConfig = Join-Path $TargetDir 'auth_api_config.json'
$backupConfig = Join-Path $backupDir 'auth_api_config.json'
if ([bool]$record.auth_config_existed -and (Test-Path -LiteralPath $backupConfig)) {
    Copy-Item -LiteralPath $backupConfig -Destination $authConfig -Force
} elseif (-not [bool]$record.auth_config_existed) {
    Remove-Item -LiteralPath $authConfig -Force -ErrorAction SilentlyContinue
}

Remove-Item -LiteralPath (Join-Path $TargetDir '_offline') -Recurse -Force -ErrorAction SilentlyContinue
foreach ($name in @('offline-launch.ps1','offline-stop.ps1','offline-diagnose.ps1','offline-patch-install.json')) {
    Remove-Item -LiteralPath (Join-Path $TargetDir $name) -Force -ErrorAction SilentlyContinue
}
Get-ChildItem -LiteralPath $TargetDir -File -Filter '*.bat' -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -match '離線模式|停止星瞳離線服務|離線診斷' } |
    Remove-Item -Force -ErrorAction SilentlyContinue

Write-Host 'Restore completed. Backup folder was preserved:' -ForegroundColor Green
Write-Host $backupDir

