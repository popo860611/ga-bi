﻿$ErrorActionPreference = 'Stop'
$appDir = $PSScriptRoot
$exeName = ([string][char]0x661F) + ([string][char]0x77B3) + '.exe'
$exePath = Join-Path $appDir $exeName
$configPath = Join-Path $appDir 'auth_api_config.json'

Write-Host '=== Offline service ==='
$health = Invoke-RestMethod -Uri 'http://127.0.0.1:8765/health' -TimeoutSec 3
$health | ConvertTo-Json -Depth 4

Write-Host '=== Verify contract ==='
$body = @{
    license_key = 'LOCAL-LAB-001'
    hwid = 'offline-diagnostic'
    session_capable = $true
} | ConvertTo-Json
$verify = Invoke-RestMethod -Uri 'http://127.0.0.1:8765/verify-license' -Method Post -ContentType 'application/json' -Body $body -TimeoutSec 5
[ordered]@{
    success = $verify.success
    reason = $verify.reason
    message = $verify.message
    contract_version = $verify.contract_version
    expires_at = $verify.expires_at
} | ConvertTo-Json

Write-Host '=== Local files ==='
if (Test-Path -LiteralPath $exePath) {
    Write-Host ('EXE SHA256: ' + (Get-FileHash -LiteralPath $exePath -Algorithm SHA256).Hash)
}
if (Test-Path -LiteralPath $configPath) {
    $bytes = [IO.File]::ReadAllBytes($configPath)
    $hasBom = $bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF
    Write-Host ('Config UTF8 BOM: ' + $hasBom)
    Get-Content -LiteralPath $configPath -Raw -Encoding UTF8
} else {
    Write-Host 'auth_api_config.json: MISSING'
}

