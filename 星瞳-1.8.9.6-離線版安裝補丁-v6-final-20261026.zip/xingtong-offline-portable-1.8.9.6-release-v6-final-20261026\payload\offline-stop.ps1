﻿$ErrorActionPreference = 'Stop'
$pidFile = Join-Path $PSScriptRoot '.mstarbot-offline-mock.pid'
$stopped = @()
if (Test-Path -LiteralPath $pidFile) {
    $serverPid = [int](Get-Content -LiteralPath $pidFile -Raw).Trim()
    $process = Get-Process -Id $serverPid -ErrorAction SilentlyContinue
    if ($process -and $process.ProcessName -eq 'MStarBotOfflineAuth') {
        Stop-Process -Id $serverPid -Force -ErrorAction SilentlyContinue
        $stopped += $serverPid
    }
}

# Fallback for missing/stale PID files.
Get-Process -Name 'MStarBotOfflineAuth' -ErrorAction SilentlyContinue | ForEach-Object {
    $stopped += $_.Id
    Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
}

if ($stopped.Count) {
    Write-Host ('已停止離線授權服務（PID：' + (($stopped | Sort-Object -Unique) -join ', ') + '）。')
} else {
    Write-Host '目前沒有執行中的離線授權服務。'
}
Remove-Item -LiteralPath $pidFile -Force -ErrorAction SilentlyContinue

