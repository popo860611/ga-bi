﻿param([switch]$NoLaunch)
$ErrorActionPreference = 'Stop'
$appDir = $PSScriptRoot
$exeName = ([string][char]0x661F) + ([string][char]0x77B3) + '.exe'
$appPath = Join-Path $appDir $exeName
$servicePath = Join-Path $appDir '_offline\MStarBotOfflineAuth.exe'
$pidFile = Join-Path $appDir '.mstarbot-offline-mock.pid'
$hostAddress = '127.0.0.1'
$port = 8765

function Test-LocalPort([string]$Address, [int]$Port) {
    $client = [System.Net.Sockets.TcpClient]::new()
    try {
        $async = $client.BeginConnect($Address, $Port, $null, $null)
        if (-not $async.AsyncWaitHandle.WaitOne(500)) { return $false }
        $client.EndConnect($async)
        return $true
    } catch { return $false } finally { $client.Dispose() }
}

function Test-OfflineService {
    try {
        $health = Invoke-RestMethod -Uri 'http://127.0.0.1:8765/health' -TimeoutSec 2
        return ([bool]$health.ok -and [string]$health.service -eq 'mstarbot-local-auth')
    } catch { return $false }
}

if (-not (Test-Path -LiteralPath $appPath)) { throw "找不到主程式：$appPath" }
if (-not (Test-Path -LiteralPath $servicePath)) { throw "找不到離線授權服務：$servicePath" }

if ((Test-LocalPort $hostAddress $port) -and -not (Test-OfflineService)) {
    throw '連接埠 8765 已被其他程式占用，並非星瞳離線授權服務。'
}

if (-not (Test-OfflineService)) {
    $server = Start-Process -FilePath $servicePath -ArgumentList @('--host',$hostAddress,'--port',"$port") -WorkingDirectory (Split-Path $servicePath) -WindowStyle Hidden -PassThru
    Set-Content -LiteralPath $pidFile -Value $server.Id -Encoding ascii
    $ready = $false
    for ($i=0; $i -lt 40; $i++) {
        Start-Sleep -Milliseconds 250
        if (Test-OfflineService) { $ready=$true; break }
        if ($server.HasExited) { break }
    }
    if (-not $ready) { throw '離線授權服務無法啟動；請確認 8765 連接埠未被其他程式占用。' }
}

$authConfig = Join-Path $appDir 'auth_api_config.json'
$authJson = @{
    auth_api_url = 'http://127.0.0.1:8765'
    script_license_api_url = 'http://127.0.0.1:8765'
} | ConvertTo-Json
[IO.File]::WriteAllText($authConfig, $authJson, [Text.UTF8Encoding]::new($false))

# AuthManager gives these process environment variables precedence over JSON.
# Set them in this launcher process so the child application inherits the
# localhost endpoints even if the other PC has stale machine/user variables.
$env:MSTARBOT_AUTH_API_URL = 'http://127.0.0.1:8765'
$env:MSTARBOT_SCRIPT_LICENSE_API_URL = 'http://127.0.0.1:8765'

function Set-JsonProperty($Object, [string]$Name, $Value) {
    if ($Object.PSObject.Properties[$Name]) { $Object.$Name = $Value }
    else { $Object | Add-Member -NotePropertyName $Name -NotePropertyValue $Value }
}

function Set-OfflineLoginCredential {
    $configPath = Join-Path $appDir 'config.json'
    $config = if (Test-Path -LiteralPath $configPath) {
        Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
    } else { [pscustomobject]@{} }
    Set-JsonProperty $config 'remember_key' $true
    Set-JsonProperty $config 'saved_key' 'LOCAL-LAB-001'
    [IO.File]::WriteAllText($configPath, ($config | ConvertTo-Json -Depth 100), [Text.UTF8Encoding]::new($false))

    $uiPath = Join-Path $appDir 'ui_state.json'
    $ui = if (Test-Path -LiteralPath $uiPath) {
        Get-Content -LiteralPath $uiPath -Raw -Encoding UTF8 | ConvertFrom-Json
    } else { [pscustomobject]@{} }
    if (-not $ui.PSObject.Properties['license_auth'] -or $null -eq $ui.license_auth) {
        Set-JsonProperty $ui 'license_auth' ([pscustomobject]@{})
    }
    Set-JsonProperty $ui.license_auth 'remember_key' $true
    Set-JsonProperty $ui.license_auth 'saved_key' 'LOCAL-LAB-001'
    [IO.File]::WriteAllText($uiPath, ($ui | ConvertTo-Json -Depth 100), [Text.UTF8Encoding]::new($false))
}

Set-OfflineLoginCredential

Write-Host '離線授權服務已就緒：http://127.0.0.1:8765/verify-license' -ForegroundColor Green
Write-Host '離線金鑰：LOCAL-LAB-001' -ForegroundColor Cyan
if (-not $NoLaunch) { Start-Process -FilePath $appPath -WorkingDirectory $appDir }


