﻿param([string]$TargetDir)
$ErrorActionPreference = 'Stop'

function Select-InstallFolder([string]$InitialPath) {
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = 'Select the XingTong folder that contains offline-service-install.json.'
    if ($InitialPath -and (Test-Path -LiteralPath $InitialPath)) { $dialog.SelectedPath = $InitialPath }
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { throw 'Removal cancelled.' }
    return $dialog.SelectedPath
}

if (-not $TargetDir) { $TargetDir = Select-InstallFolder '' }
$TargetDir = [IO.Path]::GetFullPath($TargetDir)
$recordPath = Join-Path $TargetDir 'offline-service-install.json'
if (-not (Test-Path -LiteralPath $recordPath)) { throw "Install record not found: $recordPath" }
$record = Get-Content -LiteralPath $recordPath -Raw -Encoding UTF8 | ConvertFrom-Json
$backupDir = [string]$record.backup_dir
$manifestPath = Join-Path $backupDir 'backup-manifest.json'
if (-not (Test-Path -LiteralPath $manifestPath)) { throw "Backup manifest not found: $manifestPath" }

$serviceDir = [IO.Path]::GetFullPath((Join-Path $TargetDir '_offline'))
$servicePrefix = $serviceDir + [IO.Path]::DirectorySeparatorChar
$runningService = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
    $_.ExecutablePath -and [IO.Path]::GetFullPath([string]$_.ExecutablePath).StartsWith($servicePrefix, [StringComparison]::OrdinalIgnoreCase)
}
if ($runningService) { throw 'Offline service is still running. Run the stop-service BAT first.' }

$manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
foreach ($item in $manifest.items) {
    $relative = [string]$item.relative_path
    $target = Join-Path $TargetDir $relative
    if ([bool]$item.existed) {
        $backup = Join-Path (Join-Path $backupDir 'files') $relative
        if (-not (Test-Path -LiteralPath $backup)) { throw "Backup file missing: $backup" }
        New-Item -ItemType Directory -Path (Split-Path $target -Parent) -Force | Out-Null
        Copy-Item -LiteralPath $backup -Destination $target -Force
    } else {
        Remove-Item -LiteralPath $target -Force -ErrorAction SilentlyContinue
    }
}

Remove-Item -LiteralPath $recordPath -Force
Write-Host 'Offline service files were removed/restored. 星瞳.exe was not modified.' -ForegroundColor Green
Write-Host 'Machine key was preserved in _offline. Backup folder was preserved:'
Write-Host $backupDir

