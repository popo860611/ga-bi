@echo off
setlocal
fltmc >nul 2>&1
if not "%errorlevel%"=="0" (
  powershell.exe -NoLogo -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1" %*
set "rc=%errorlevel%"
echo.
if not "%rc%"=="0" echo Removal failed. Exit code: %rc%
pause
exit /b %rc%
