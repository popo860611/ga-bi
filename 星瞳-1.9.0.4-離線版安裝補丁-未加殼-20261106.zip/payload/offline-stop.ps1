﻿$ErrorActionPreference = 'Stop'
$pidFile = Join-Path $PSScriptRoot '.mstarbot-offline-mock.pid'
$serviceDir = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '_offline'))
$stopped = @()
if (Test-Path -LiteralPath $pidFile) {
    $serverPid = [int](Get-Content -LiteralPath $pidFile -Raw).Trim()
    $process = Get-Process -Id $serverPid -ErrorAction SilentlyContinue
    if ($process -and $process.ProcessName -eq 'MStarBotOfflineAuth') {
        Stop-Process -Id $serverPid -Force -ErrorAction SilentlyContinue
        $stopped += $serverPid
    }
}

# Fallback for missing/stale PID files.
Get-Process -Name 'MStarBotOfflineAuth' -ErrorAction SilentlyContinue | ForEach-Object {
    $stopped += $_.Id
    Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
}

# The protected launcher decrypts the native service to a temporary .omp-*.exe
# in _offline. Stopping only the launcher can leave that child alive, so stop
# only temporary children whose executable path is inside this installation.
Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
    $_.ExecutablePath -and
    $_.Name -like '.omp-*.exe' -and
    [IO.Path]::GetFullPath([string]$_.ExecutablePath).StartsWith(
        $serviceDir + [IO.Path]::DirectorySeparatorChar,
        [StringComparison]::OrdinalIgnoreCase)
} | ForEach-Object {
    $stopped += [int]$_.ProcessId
    Stop-Process -Id ([int]$_.ProcessId) -Force -ErrorAction SilentlyContinue
}

if ($stopped.Count) {
    Write-Host ('已停止離線授權服務（PID：' + (($stopped | Sort-Object -Unique) -join ', ') + '）。')
} else {
    Write-Host '目前沒有執行中的離線授權服務。'
}
Remove-Item -LiteralPath $pidFile -Force -ErrorAction SilentlyContinue

